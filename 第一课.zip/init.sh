#! /bin/bash

if command -v git >/dev/null 2>&1; then 
	echo 'exists git'
else
	echo 'can not found git'
	exit
fi

#1 gocode
git clone https://github.com/nsf/gocode.git src/github.com/nsf/gocode
#2 gopkgs
git clone https://github.com/tpng/gopkgs.git src/github.com/tpng/gopkgs
#go-outline
git clone https://github.com/lukehoban/go-outline.git src/github.com/lukehoban/go-outline
#3 go-symbols
git clone https://github.com/newhook/go-symbols.git src/go-symbols
#4 guru
#5 gorename
#6 golint
git clone https://github.com/golang/tools.git src/golang.org/x/tools
#7 godep
git clone https://github.com/tools/godep.git src/github.com/tools/godep
#8 gomodifytags
git clone https://github.com/fatih/gomodifytags.git src/github.com/fatih/gomodifytags
#9 impl
git clone https://github.com/josharian/impl.git src/github.com/josharian/impl
#10 godef
git clone https://github.com/rogpeppe/godef.git src/github.com/rogpeppe/godef
#11 goreturns
git clone https://github.com/sqs/goreturns.git src/github.com/sqs/goreturns
#12 gotests
git clone https://github.com/cweill/gotests.git src/github.com/cweill/gotests

#安装goreturns
go install golang.org/x/tools/imports
go install golang.org/x/tools/go/buildutil
go install golang.org/x/tools/cmd/guru
go install golang.org/x/tools/cmd/gorename
go install github.com/nsf/gocode
go install github.com/sqs/goreturns
go install go-symbols
go install github.com/tpng/gopkgs
go install github.com/lukehoban/go-outline
go install github.com/tools/godep
go install github.com/josharian/impl
go install github.com/rogpeppe/godef
go install github.com/sqs/goreturns
go install github.com/cweill/gotests/gotests
go install github.com/fatih/gomodifytags
go install github.com/golang/lint/golint