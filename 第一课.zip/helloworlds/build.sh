#! /bin/bash

export GOPATH="/Users/liqiang/go":$(pwd)
echo $GOPATH
go build hello